THE WELLBORE FLUID RACE
Windows x86-64

فك ضغط الملفات كلها بمجلد واحد، وبعدين افتح WellboreFluidRace.exe.
خلي WellboreFluidRace.pck بنفس مجلد البرنامج.
تشتغل اللعبة بدون إنترنت. زر العربية يبدّل لغة الترجمة.

Extract the entire archive into one folder and open WellboreFluidRace.exe.
Keep WellboreFluidRace.pck in the same folder as the executable.
The game runs offline. Use the language button to switch subtitle language.

Godot Engine and Noto Font notices are in the licenses folder.
